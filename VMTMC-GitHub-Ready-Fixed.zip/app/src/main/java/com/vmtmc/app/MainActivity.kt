package com.vmtmc.app

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var nameA: EditText; private lateinit var nameB: EditText
    private lateinit var extractedA: TextView; private lateinit var extractedB: TextView
    private lateinit var result: TextView; private lateinit var progress: TextView
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var fileA: Uri? = null; private var fileB: Uri? = null
    private val pickA = 101; private val pickB = 102

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,18,24,24); setBackgroundColor(android.graphics.Color.rgb(5,5,5)) }
        val scroll = ScrollView(this); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val title=TextView(this).apply{text="VMTMC";textSize=30f;setTextColor(-1);gravity=Gravity.CENTER;setTypeface(null,1)}
        val sub=TextView(this).apply{text="Name Matcher";textSize=17f;setTextColor(android.graphics.Color.rgb(167,139,250));gravity=Gravity.CENTER}
        box.addView(title); box.addView(sub); box.addView(info("PDF / Image → OCR → Name Match"))
        box.addView(section("DOCUMENT / IMAGE A", true)); box.addView(extractedAView())
        box.addView(section("DOCUMENT / IMAGE B", false)); box.addView(extractedBView())
        box.addView(label("NAME 1")); nameA=edit("Dheeraj Kumar Prajapati"); box.addView(nameA)
        box.addView(label("NAME 2")); nameB=edit("Prajapati Dheeraj Kumar"); box.addView(nameB)
        val compare=Button(this).apply{text="MATCH NAMES";setOnClickListener{compareNames()}}; box.addView(compare)
        progress=info(""); box.addView(progress)
        result=info("Result will appear here"); box.addView(result)
        box.addView(info("Rules: word order ignored; extra middle words allowed; capitalization and punctuation are exact."))
        scroll.addView(box); root.addView(scroll, ViewGroup.LayoutParams(-1,0).apply{weight=1f}); setContentView(root)
    }
    private fun info(s:String)=TextView(this).apply{text=s;textSize=14f;setTextColor(android.graphics.Color.LTGRAY);setPadding(8,14,8,14)}
    private fun label(s:String)=TextView(this).apply{text=s;textSize=13f;setTextColor(android.graphics.Color.LTGRAY);setPadding(0,12,0,4)}
    private fun edit(s:String)=EditText(this).apply{setText(s);setTextColor(-1);setHintTextColor(android.graphics.Color.GRAY);setHint("Enter name");setSingleLine(false);setPadding(14,10,14,10)}
    private fun section(s:String,a:Boolean): LinearLayout { val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; val t=TextView(this).apply{text=s;textSize=15f;setTextColor(-1);setTypeface(null,1)}; l.addView(t); val b=Button(this).apply{text="UPLOAD PDF / IMAGE";setOnClickListener{pick(if(a)pickA else pickB)}}; l.addView(b); return l }
    private fun extractedAView()=TextView(this).also{extractedA=it;it.text="No file uploaded";it.setTextColor(android.graphics.Color.GRAY);it.setPadding(8,4,8,12)}
    private fun extractedBView()=TextView(this).also{extractedB=it;it.text="No file uploaded";it.setTextColor(android.graphics.Color.GRAY);it.setPadding(8,4,8,12)}
    private fun pick(code:Int){startActivityForResult(android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(android.content.Intent.EXTRA_MIME_TYPES,arrayOf("application/pdf","image/jpeg","image/png","image/webp"));addCategory(android.content.Intent.CATEGORY_OPENABLE)},code)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:android.content.Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode==RESULT_OK){val u=data?.data?:return;contentResolver.takePersistableUriPermission(u,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);if(requestCode==pickA){fileA=u;extractedA.text="Selected: ${displayName(u)}";ocr(u,true)}else{fileB=u;extractedB.text="Selected: ${displayName(u)}";ocr(u,false)}}}
    private fun displayName(u:Uri):String{var n="file";contentResolver.query(u,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())n=it.getString(0)};return n}
    private fun ocr(uri:Uri,isA:Boolean){progress.text="Extracting text…";Thread{try{val text=if(displayName(uri).lowercase(Locale.US).endsWith(".pdf")) ocrPdf(uri) else ocrImage(uri);runOnUiThread{if(isA)extractedA.text="OCR:\n$text" else extractedB.text="OCR:\n$text";progress.text="OCR complete. Enter/review the name fields and tap MATCH NAMES."}}catch(e:Exception){runOnUiThread{progress.text="OCR error: ${e.message}"}}}.start()}
    private fun ocrImage(uri:Uri):String{val img=InputImage.fromFilePath(this,uri);return ocrTask(img)}
    private fun ocrTask(img:InputImage):String{var out="";val lock=Object();var done=false;recognizer.process(img).addOnSuccessListener{out=it.text;synchronized(lock){done=true;lock.notify()}}.addOnFailureListener{synchronized(lock){done=true;lock.notify()}};synchronized(lock){while(!done)lock.wait()};return out}
    private fun ocrPdf(uri:Uri):String{val pfd=contentResolver.openFileDescriptor(uri,"r")?:return "";val r=PdfRenderer(pfd);val sb=StringBuilder();for(i in 0 until r.pageCount){val p=r.openPage(i);val bmp=Bitmap.createBitmap(p.width*2,p.height*2,Bitmap.Config.ARGB_8888);bmp.eraseColor(-1);p.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);val img=InputImage.fromBitmap(bmp,0);sb.append(ocrTask(img)).append("\n");p.close();bmp.recycle()};r.close();pfd.close();return sb.toString()}
    private fun compareNames(){val a=nameA.text.toString().trim();val b=nameB.text.toString().trim();if(a.isEmpty()||b.isEmpty()){result.text="DIFFERENT\nOne or both names are empty.";return};val A=a.split(Regex("\\s+")).filter{it.isNotEmpty()};val B=b.split(Regex("\\s+")).filter{it.isNotEmpty()};val ok=if(A.size<=B.size)containsAll(B,A)else containsAll(A,B);if(ok){result.setTextColor(android.graphics.Color.rgb(74,222,128));result.text="✓ MATCH\nOrder ignored. Name words matched exactly, including case and punctuation."}else{result.setTextColor(android.graphics.Color.rgb(248,113,113));result.text="✕ DIFFERENT\nSpelling, capitalization, punctuation, or required word(s) differ."}}
    private fun containsAll(big:List<String>,small:List<String>):Boolean{val m=big.groupingBy{it}.eachCount().toMutableMap();for(x in small){val n=m[x]?:0;if(n==0)return false;m[x]=n-1};return true}
}
