# VMTMC — Visual / Multi-Text Name Matcher

Android Studio project for matching names extracted from PDFs/images.

## Matching rule
- Word order is ignored.
- The shorter name may be contained in the longer name, so extra middle-name words are allowed.
- Case is significant.
- Punctuation/special characters are significant.

Examples:
- `Dheeraj Kumar Prajapati` ↔ `Prajapati Dheeraj Kumar` = MATCH
- `Dheeraj Kumar Prajapati` ↔ `Dheeraj Kumar Brijpal Prajapati` = MATCH
- `Jhon Peter Yadav` ↔ `jhon peaTer yAdav` = DIFFERENT
- `Dheeraj-Kumar` ↔ `Dheeraj Kumar` = DIFFERENT

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).
The ML Kit OCR dependency is downloaded by Gradle during the first build.
