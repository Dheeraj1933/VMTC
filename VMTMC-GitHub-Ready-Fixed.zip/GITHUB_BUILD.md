# VMTMC — GitHub APK Build

1. Create a GitHub repository.
2. Upload the contents of this project (not the ZIP itself).
3. Commit to the `main` branch.
4. Open **Actions → Build VMTMC APK → Run workflow**.
5. When the build finishes, open the workflow run and download **VMTMC-release-apk**.
6. Extract the artifact ZIP and install the APK on Android.

No Android Studio is required for the GitHub build.
